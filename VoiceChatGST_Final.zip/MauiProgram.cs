
using Microsoft.Extensions.Logging;
using VoiceChatGST.Services;
using VoiceChatGST.ViewModels;

namespace VoiceChatGST;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
            });

#if DEBUG
        builder.Logging.AddDebug();
#endif

        // Dependency Injection
        builder.Services.AddSingleton<IVoiceToTextService, OpenAIWhisperService>();
        builder.Services.AddSingleton<VoiceInputViewModel>();
#if WINDOWS
        builder.Services.AddSingleton<TrayIconService>();
#endif

        return builder.Build();
    }
}
