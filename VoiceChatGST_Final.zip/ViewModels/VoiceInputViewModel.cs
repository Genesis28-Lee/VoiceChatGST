using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace VoiceChatGST.ViewModels;

public class VoiceInputViewModel : INotifyPropertyChanged
{
    private readonly IVoiceToTextService _voiceService;

    public VoiceInputViewModel(IVoiceToTextService voiceService)
    {
        _voiceService = voiceService;
    }

    public ICommand StartListeningCommand => new Command(async () =>
    {
        var result = await _voiceService.StartListeningAsync();
        if (!string.IsNullOrEmpty(result))
        {
            RecognizedText = result;
        }
    });

    private string _recognizedText;
    public string RecognizedText
    {
        get => _recognizedText;
        set { _recognizedText = value; OnPropertyChanged(); }
    }

    public event PropertyChangedEventHandler PropertyChanged;
    protected void OnPropertyChanged([CallerMemberName] string name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
