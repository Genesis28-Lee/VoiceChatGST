
using NAudio.Wave;

namespace VoiceChatGST.Services;

public class AudioRecorder
{
    private readonly string _outputPath = Path.Combine(FileSystem.CacheDirectory, "audio.wav");

    public async Task<string> RecordAsync(int seconds = 5)
    {
        using var waveIn = new WaveInEvent();
        using var writer = new WaveFileWriter(_outputPath, waveIn.WaveFormat);

        waveIn.DataAvailable += (s, a) =>
        {
            writer.Write(a.Buffer, 0, a.BytesRecorded);
        };

        var tcs = new TaskCompletionSource<bool>();
        waveIn.RecordingStopped += (s, a) => tcs.SetResult(true);

        waveIn.StartRecording();
        await Task.Delay(TimeSpan.FromSeconds(seconds));
        waveIn.StopRecording();
        await tcs.Task;

        return _outputPath;
    }
}
