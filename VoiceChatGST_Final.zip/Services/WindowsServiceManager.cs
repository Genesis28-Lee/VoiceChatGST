using System.ServiceProcess;

namespace VoiceChatGST.Services;

public class WindowsServiceManager
{
    private readonly string _serviceName;

    public WindowsServiceManager(string serviceName)
    {
        _serviceName = serviceName;
    }

    public void StartService()
    {
        using var controller = new ServiceController(_serviceName);
        if (controller.Status != ServiceControllerStatus.Running)
            controller.Start();
    }

    public void StopService()
    {
        using var controller = new ServiceController(_serviceName);
        if (controller.Status != ServiceControllerStatus.Stopped)
            controller.Stop();
    }

    public void RestartService()
    {
        StopService();
        Thread.Sleep(2000);
        StartService();
    }
}
