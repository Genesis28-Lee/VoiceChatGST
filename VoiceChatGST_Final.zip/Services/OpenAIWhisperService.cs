using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;

namespace VoiceChatGST.Services;

public class OpenAIWhisperService : IVoiceToTextService
{
    private readonly HttpClient _httpClient;

    public OpenAIWhisperService()
    {
        _httpClient = new HttpClient();
        _httpClient.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", "YOUR_OPENAI_API_KEY");
    }

    public async Task<string> StartListeningAsync()
    {
        var audioFilePath = await RecordAudioAsync(); // 구현 필요
        var content = new MultipartFormDataContent();
        content.Add(new ByteArrayContent(await File.ReadAllBytesAsync(audioFilePath)), "file", "audio.wav");
        content.Add(new StringContent("whisper-1"), "model");

        var response = await _httpClient.PostAsync("https://api.openai.com/v1/audio/transcriptions", content);
        var json = await response.Content.ReadAsStringAsync();
        return JObject.Parse(json)["text"]?.ToString();
    }

    private async Task<string> RecordAudioAsync()
    {
        // 플랫폼별 마이크 녹음 구현 필요
        throw new NotImplementedException();
    }
}
