#if WINDOWS
using Microsoft.UI;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using System.Runtime.InteropServices;
using Windows.Win32;
using Windows.Win32.Foundation;
using Windows.Win32.UI.Shell;
using Windows.Win32.UI.WindowsAndMessaging;

namespace VoiceChatGST.Services;

public class TrayIconService : IDisposable
{
    private readonly NotifyIcon _notifyIcon;

    public TrayIconService()
    {
        _notifyIcon = new NotifyIcon
        {
            Icon = SystemIcons.Application,
            Visible = true,
            Text = "VoiceChatGST"
        };

        _notifyIcon.ContextMenuStrip = new ContextMenuStrip();
        _notifyIcon.ContextMenuStrip.Items.Add("Start Service", null, (s, e) => OnStart?.Invoke());
        _notifyIcon.ContextMenuStrip.Items.Add("Stop Service", null, (s, e) => OnStop?.Invoke());
        _notifyIcon.ContextMenuStrip.Items.Add("Restart Service", null, (s, e) => OnRestart?.Invoke());
        _notifyIcon.ContextMenuStrip.Items.Add("Exit", null, (s, e) => Application.Current.Quit());
    }

    public event Action OnStart;
    public event Action OnStop;
    public event Action OnRestart;

    public void Dispose()
    {
        _notifyIcon.Visible = false;
        _notifyIcon.Dispose();
    }
}
#endif
