namespace VoiceChatGST.Services;

public interface IVoiceToTextService
{
    Task<string> StartListeningAsync();
}
